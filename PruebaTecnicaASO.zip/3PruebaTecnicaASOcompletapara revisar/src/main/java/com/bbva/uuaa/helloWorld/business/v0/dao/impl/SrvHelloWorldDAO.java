package com.bbva.uuaa.helloWorld.business.v0.dao.impl;

import com.bbva.uuaa.helloWorld.business.v0.dao.ISrvHelloWorldDAO;
import com.bbva.uuaa.helloWorld.business.v0.dto.*;
import org.springframework.stereotype.Component;

import java.util.Random;

@Component(value = "srvHelloWorldDAO")
public class SrvHelloWorldDAO implements ISrvHelloWorldDAO {

    //metodo genera  porcentages a maximumAmount y minimumAmount  e introducion de datos en
    //Objetos correspondientes para que devuelva lo que requiere la prueba tecnica
    @Override
    public BSimulationOut mapSimulationDao(BSimulation bSimulation) {
        BSimulationOut bSimulationOut = new BSimulationOut();

        bSimulationOut.setId(generateId());
        bSimulationOut.setNuip(bSimulation.getNuip());

        BDetails bDetails = new BDetails();
        bDetails.setOfferType(bSimulation.getDetails().getOfferType());

        BLimitAmount bLimitAmount = new BLimitAmount();
        bLimitAmount.setAmount(bSimulation.getDetails().getLimitAmount().getAmount());
        bLimitAmount.setCurrency(bSimulation.getDetails().getLimitAmount().getCurrency());
        bDetails.setLimitAmount(bLimitAmount);


        BMaximumAmount bMaximumAmount = new BMaximumAmount();
        bMaximumAmount.setAmount(bLimitAmount.getAmount() * 1.05);
        bMaximumAmount.setCurrency(bLimitAmount.getCurrency());
        bDetails.setMaximumAmount(bMaximumAmount);

        BMinimumAmount bMinimumAmount = new BMinimumAmount();
        bMinimumAmount.setAmount(bLimitAmount.getAmount() * 0.9);
        bMinimumAmount.setCurrency(bLimitAmount.getCurrency());
        bDetails.setMinimumAmount(bMinimumAmount);

        BProduct bProduct = new BProduct();
        bProduct.setId(bSimulation.getDetails().getProduct().getId());

        BSubproduct bSubproduct = new BSubproduct();
        bSubproduct.setId(bSimulation.getDetails().getProduct().getSubproduct().getId());
        bProduct.setSubproduct(bSubproduct);

        bDetails.setProduct(bProduct);

        bSimulationOut.setDetails(bDetails);
        return bSimulationOut;
    }
    //metodo genera id aleatorio con letras numeros y caracteres especiales
    public String generateId() {
        final String CHARACTERS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&";;
        Random random = new Random();
        StringBuilder idBuilder = new StringBuilder();

        for (int i = 0; i < 10; i++) {
            int randomIndex = random.nextInt(CHARACTERS.length());
            char randomChar = CHARACTERS.charAt(randomIndex);
            idBuilder.append(randomChar);
        }

        return idBuilder.toString();
    }

}
