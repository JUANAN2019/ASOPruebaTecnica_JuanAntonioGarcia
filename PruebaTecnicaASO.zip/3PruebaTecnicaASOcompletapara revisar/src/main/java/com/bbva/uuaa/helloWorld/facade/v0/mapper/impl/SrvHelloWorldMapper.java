package com.bbva.uuaa.helloWorld.facade.v0.mapper.impl;


import org.springframework.stereotype.Component;

@Component(value = "srvHelloWorldMapper")
public class SrvHelloWorldMapper {



}
