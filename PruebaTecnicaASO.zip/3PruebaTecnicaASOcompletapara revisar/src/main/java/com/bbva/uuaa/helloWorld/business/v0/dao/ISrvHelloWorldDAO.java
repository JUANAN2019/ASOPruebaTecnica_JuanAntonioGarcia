package com.bbva.uuaa.helloWorld.business.v0.dao;

import com.bbva.uuaa.helloWorld.business.v0.dto.*;

public interface ISrvHelloWorldDAO {

    BSimulationOut mapSimulationDao(BSimulation bSimulation);
}
